@echo off
setlocal
set "APP_URL=https://ais-dev-uezvraxz5h2xsf4xr5nkjk-789221242334.asia-southeast1.run.app/?mode=pc"
echo ==================================================
echo   LensLink PC Desktop Installer (Windows 10 / 11)
echo ==================================================
echo.
set "BROWSER_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER_EXE (
  echo Microsoft Edge or Google Chrome not found in default paths.
  echo Opening in your default browser instead...
  start "" "%APP_URL%"
  pause
  exit /b 0
)
echo Creating Desktop and Start Menu shortcuts for LensLink...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LensLink.lnk'; foreach ($path in @((Join-Path $desktop 'LensLink.lnk'), $startMenu)) { $s = $ws.CreateShortcut($path); $s.TargetPath = '%BROWSER_EXE%'; $s.Arguments = '--app=%APP_URL% --new-window'; $s.Description = 'LensLink Wireless Smartphone Webcam'; $s.Save() }"
echo.
echo Shortcut installed! Launching LensLink PC Receiver...
start "" "%BROWSER_EXE%" --app="%APP_URL%" --new-window
exit /b 0
