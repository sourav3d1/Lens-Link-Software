LensLink PC Desktop Application (Windows 10 / 11)
==================================================

1. Install Desktop Shortcut:
   Double-click Install_LensLink_Desktop.bat to add a LensLink icon
   to your Windows Desktop and Start Menu and launch it as a standalone app.

2. Portable Quick Launch:
   Double-click Launch_LensLink.bat anytime to open a fresh session window.

3. Multi-PC & Multi-Smartphone on the Same Wi-Fi:
   Each time LensLink opens on any PC, it generates a unique dynamic QR code
   and 6-character session code. Scan each PC's QR code with its paired
   smartphone so multiple workstations operate independently on the same Wi-Fi.

4. Windows Virtual Webcam (No OBS Studio Required):
   Open the included virtual-cam folder and run Install_Driver_No_OBS.bat
   followed by start_virtual_cam.bat to expose a native DirectShow webcam.
